%% DEFINE PARAMETERS

params.MassOfUAV = 2;
params.MassOfp1 = 0.10;
params.MassOfp2 = 0.10;

params.AccelerationDueToGravity = 9.79;

params.UAV.J = eye(3);
params.UAV.G = zeros(3,1);

params.p1.J = eye(3);
params.p1.G = [0;0;-1];

params.p2.J = eye(3);
params.p2.G = [0;0;-1];

params.UAV.pos = ones(3,1);

params.p1.pos = [1 ;0; 0];

params.p2.pos = [1 ;0; 0];


%% IMPLEMENT 4th ORDER RUNGA-KUTTA INTEGRATION

tSim = 1; % [s] Simulation Time
dt = 0.01; % [s] Simulation Time Step

t = 0:dt:tSim; % [s] simulation time

Fs = 20; % [Hz] Sample Rate/Processor Clock Speed (whichever is slower)
Ts = 1/Fs; % [s] Sampling interval
T_last = -Ts;

gamma = zeros(16, length(t));
gamma(3,1) = 10; % start with it above the ground. 
%gamma(7,1) = pi/2;

err_ = zeros(2,1);
errInt_ = zeros(2,1);

F = zeros(8,1);

for ii = 1:length(t) - 1
    if t(ii) - T_last >= Ts
        
        F(7) = 1;
        gamma(:,11) = 4;
    end  
    [k1,G] = UAVDynamics(t(ii),gamma(:,ii), F, params);
    [k2,G] = UAVDynamics(t(ii),gamma(:,ii)+k1*dt/2, F, params);
    [k3,G] = UAVDynamics(t(ii),gamma(:,ii)+k2*dt/2, F, params);
    [k4,G] = UAVDynamics(t(ii),gamma(:,ii)+k3*dt, F, params);
    gamma(:,ii+1) = gamma(:,ii) + dt*(k1(:,1)/6 + k2(:,1)/3 + k3(:,1)/3 + k4(:,1)/6);
end

% Plot Joint Variables
figure(1);

subplot(7,1,1);
plot(t, gamma(1,:), 'b-');
xlabel('t (s)');
ylabel('x (m)');

subplot(7,1,2);
plot(t, gamma(2,:), 'b-');
xlabel('t (s)');
ylabel('y (m)');

subplot(7,1,3);
plot(t, gamma(3,:), 'b-');
xlabel('t (s)');
ylabel('z (rad)');

subplot(7,1,4);
plot(t, gamma(4,:), 'b-');
xlabel('t (s)');
ylabel('\theta (rad)');

subplot(7,1,5);
plot(t, gamma(5,:), 'b-');
xlabel('t (s)');
ylabel('\psi (rad)');

subplot(7,1,6);
plot(t, gamma(6,:), 'b-');
xlabel('t (s)');
ylabel('\alpha_1 (rad)');

subplot(7,1,7);
plot(t, gamma(7,:), 'b-');
xlabel('t (s)');
ylabel('\alpha_2 (rad)');
hold on
% figure(2);
% 
% plot(t, G(4), 'b-');
% xlabel('t (s)');
% ylabel('G');


