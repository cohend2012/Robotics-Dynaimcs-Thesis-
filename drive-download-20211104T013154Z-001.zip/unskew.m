function [ w ] = unskew( Sk )
    w = [Sk(3,2); Sk(1,3); Sk(2,1)];
end

